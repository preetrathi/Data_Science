# Banking API — Secure FastAPI Starter

A production-grade FastAPI scaffold for a banking-adjacent API, built around
three priorities: **security by architecture** (not bolted-on later),
**observability** (structured + audit logging), and **portability**
(runs identically via Docker, on Linux, and on Windows).

## 1. How the code is organized, and why

```
app/
├── main.py                  # App factory: wires middleware, routers, exception handlers
├── core/
│   ├── config.py             # All settings, read from env — nothing hardcoded
│   ├── security.py           # ONLY place password hashing / JWT logic lives
│   ├── logging_config.py     # Structured JSON logging + separate audit log
│   ├── middleware.py         # Correlation ID + security headers
│   ├── exceptions.py         # Global handlers — never leak internals to clients
│   └── rate_limit.py         # SlowAPI limiter instance
├── api/
│   ├── deps.py                # get_current_user, require_role — auth guards
│   └── v1/endpoints/          # Route handlers — thin, no business logic here
├── models/                    # SQLAlchemy ORM models (the DB schema, in code)
├── schemas/                   # Pydantic request/response contracts — the validation layer
├── crud/                      # ONLY layer allowed to query the DB
└── db/                        # Engine + session management
```

**Why layers matter:** an endpoint function should read like a summary —
"validate input, call the service/CRUD layer, return the result." All the
actual logic (hashing, token creation, DB queries) lives in dedicated
modules. This means:
- You can unit-test `core/security.py` without a database or HTTP server.
- If a security review needs to check "where do we touch the DB?" the
  answer is always "only in `crud/`" — one place to audit, not scattered
  across 30 endpoint files.
- Adding a new resource (e.g. `accounts`, `transactions`) means adding a
  model + schema + crud + endpoint file, following the same pattern
  every time — this is how you keep a "large scale" API maintainable as
  it grows to hundreds of endpoints.

## 2. Security measures already built in — and what they defend against

| Measure | Defends against |
|---|---|
| SQLAlchemy ORM only, no raw SQL string-building | SQL injection |
| Pydantic schemas with `extra="forbid"` | Mass assignment (e.g. client sneaking `role=admin` into a request) |
| Password strength validator + bcrypt hashing | Credential stuffing, offline brute force of stolen hashes |
| Short-lived JWT access tokens + rotating refresh tokens | Stolen-token blast radius |
| Per-IP rate limiting on login (`slowapi`) | Online brute force |
| Account lockout after N failed logins | Targeted brute force against one account |
| Generic "incorrect email or password" message | Account enumeration |
| Docs (`/docs`, `/openapi.json`) disabled in production | API surface reconnaissance |
| Security headers middleware (HSTS, CSP, X-Frame-Options, etc.) | Clickjacking, MIME sniffing, protocol downgrade |
| CORS explicit allow-list (never `*`) | Cross-origin credential theft |
| Global exception handlers hiding stack traces | Information disclosure |
| Structured audit log for auth events | Forensics / incident investigation |
| `.env` git-ignored, secrets only from env/secrets manager | Credentials leaking into source control |
| Non-root Docker user, systemd sandboxing, dedicated Linux service account | Blast radius if the process is compromised |

**What you still need to add as you go (not yet in this scaffold — ask me
for any of these next):**
- HTTPS/TLS termination (Nginx config included for Linux; IIS binding
  for Windows) — the app itself should never terminate TLS directly in production
- A WAF in front of the API (cloud provider WAF or on-prem appliance)
- Dependency vulnerability scanning in CI (`pip-audit` is in `requirements/dev.txt` — run it regularly)
- Centralized log shipping (the app writes structured JSON logs — ship them to ELK/Splunk/Azure Monitor)
- Secrets manager integration (Key Vault / Vault / Secrets Manager) instead of `.env` in UAT/prod
- Check with your compliance team whether PCI-DSS, your central bank's API security standard, or ISO 27001 controls impose additional mandatory requirements (encryption at rest, specific audit retention periods, etc.)

## 3. Running locally

```bash
python -m venv .venv
.venv\Scripts\activate        # Windows
source .venv/bin/activate     # Linux/Mac

pip install -r requirements/dev.txt
cp .env.example .env          # then edit .env with real local values

# Run tests first (uses in-memory SQLite, no real DB needed)
pytest -v

# Run the app
uvicorn app.main:app --reload
```

Or with Docker (spins up SQL Server too):
```bash
docker compose up --build
```

## 4. Database migrations (Alembic)

Never modify the SQL Server schema by hand. Always go through a migration:

```bash
alembic revision --autogenerate -m "create users table"
alembic upgrade head
```

This gives you a version-controlled history of every schema change —
essential for both auditability and safely rolling back in production.

## 5. Testing strategy

- `tests/unit/` — pure logic, no DB, no HTTP (e.g. `test_security.py`)
- `tests/integration/` — full request/response cycle via `TestClient`,
  against an in-memory SQLite DB (`test_auth.py` includes security-relevant
  tests: rejecting weak passwords, rejecting mass-assignment, generic
  error messages, blocking unauthenticated access)

Before promoting to UAT, add a smaller suite of **integration tests
against a real SQL Server instance** to catch SQL-Server-specific
behavior (collation, data types) that SQLite won't reveal.

## 6. Deployment

### Linux (production)
1. `scripts/setup_linux.sh` — creates a dedicated `bankingapp` system
   user (no login shell), installs dependencies, registers the systemd
   service.
2. `scripts/banking-api.service` — runs Gunicorn managing 4 Uvicorn
   workers, with systemd sandboxing (`ProtectSystem=strict`, `NoNewPrivileges`).
3. `scripts/nginx-banking-api.conf` — Nginx terminates TLS and reverse-proxies to Gunicorn.

### Windows (UAT and production)
1. `scripts/setup_windows.ps1` — creates the virtual environment and
   installs dependencies.
2. Register as a Windows Service using **NSSM** (the script prints the
   exact commands) so it survives reboots and restarts automatically on crash.
3. Put **IIS** in front as a reverse proxy (URL Rewrite + Application
   Request Routing modules) to terminate TLS and forward to the
   Uvicorn process on `127.0.0.1:8000`.

Both environments run the exact same application code — only the process
manager and reverse proxy differ. This is deliberate: it means whatever
you validate in UAT (Windows) behaves identically when you deploy to
Linux production.

## 7. Logging

- `logs/app.log` — general application/access log (JSON, rotated daily, 30-day retention)
- `logs/audit.log` — security-relevant events only: registrations, logins
  (success/failure/locked), token refreshes (JSON, rotated daily,
  365-day retention — adjust to your regulator's required retention period)
- Every log line includes a `request_id` that also comes back to the
  client in the `X-Request-ID` response header — when a customer or
  another team reports an issue, that ID lets you find the exact log
  lines instantly.
- Sensitive fields (passwords, tokens, card numbers) are never logged —
  see `mask_sensitive()` in `core/logging_config.py` if you add logging
  calls that include a user-supplied dict.

## 8. Suggested next steps (in order)

1. Run the test suite, read through `test_auth.py` — it's written to
   double as a walkthrough of the security behaviors.
2. Add your second resource (e.g. `accounts`) following the same
   model → schema → crud → endpoint pattern as `users`.
3. Stand up a real SQL Server instance (or use `docker compose up`) and
   run `alembic upgrade head` against it.
4. Deploy to your Windows UAT box using `setup_windows.ps1`, and run the
   integration test suite against it.
5. From there, we set up CI (test + `pip-audit` on every commit) and a
   promotion pipeline from UAT to your Linux/Windows production servers.
