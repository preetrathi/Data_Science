from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.logging_config import audit_logger
from app.core.security import create_access_token, create_refresh_token, decode_token, verify_password
from app.crud.user import (
    create_user,
    get_user_by_email,
    register_failed_login,
    reset_failed_logins,
)
from app.core.rate_limit import limiter
from app.db.session import get_db
from app.schemas.user import LoginRequest, RefreshRequest, Token, UserCreate, UserOut

settings = get_settings()
router = APIRouter()


@router.post("/register", response_model=UserOut, status_code=status.HTTP_201_CREATED)
def register(user_in: UserCreate, request: Request, db: Session = Depends(get_db)):
    if get_user_by_email(db, user_in.email):
        # Deliberately generic message — don't confirm/deny which emails
        # already exist in the system (an "account enumeration" leak).
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Registration failed")

    user = create_user(db, user_in)
    audit_logger.info(
        "user_registered",
        extra={"request_id": request.state.request_id, "user_id": user.id, "email": user.email},
    )
    return user


@router.post("/login", response_model=Token)
@limiter.limit(settings.RATE_LIMIT_LOGIN)  # brute-force defense #1: IP-based rate limit
def login(login_in: LoginRequest, request: Request, db: Session = Depends(get_db)):
    user = get_user_by_email(db, login_in.email)

    generic_error = HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Incorrect email or password")

    if user is None:
        # Same generic error whether the email doesn't exist or the
        # password is wrong — again, no account enumeration.
        raise generic_error

    if user.locked_until and user.locked_until > datetime.now(timezone.utc):
        audit_logger.warning(
            "login_blocked_account_locked",
            extra={"request_id": request.state.request_id, "user_id": user.id},
        )
        raise HTTPException(status_code=status.HTTP_423_LOCKED, detail="Account temporarily locked. Try again later.")

    if not verify_password(login_in.password, user.hashed_password):
        register_failed_login(db, user)  # brute-force defense #2: account lockout
        audit_logger.warning(
            "login_failed",
            extra={"request_id": request.state.request_id, "user_id": user.id},
        )
        raise generic_error

    reset_failed_logins(db, user)
    audit_logger.info(
        "login_succeeded",
        extra={"request_id": request.state.request_id, "user_id": user.id},
    )

    return Token(
        access_token=create_access_token(subject=user.id, extra_claims={"role": user.role}),
        refresh_token=create_refresh_token(subject=user.id),
    )


@router.post("/refresh", response_model=Token)
def refresh_token(payload_in: RefreshRequest, request: Request, db: Session = Depends(get_db)):
    payload = decode_token(payload_in.refresh_token)
    if payload is None or payload.get("type") != "refresh":
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid refresh token")

    user_id = payload.get("sub")
    from app.crud.user import get_user_by_id
    user = get_user_by_id(db, user_id)
    if user is None or not user.is_active:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid refresh token")

    audit_logger.info("token_refreshed", extra={"request_id": request.state.request_id, "user_id": user.id})

    return Token(
        access_token=create_access_token(subject=user.id, extra_claims={"role": user.role}),
        refresh_token=create_refresh_token(subject=user.id),  # rotate refresh token too
    )
