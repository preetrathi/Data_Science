from fastapi import APIRouter, Depends

from app.api.deps import get_current_user, require_role
from app.models.user import User
from app.schemas.user import UserOut

router = APIRouter()


@router.get("/me", response_model=UserOut)
def read_current_user(current_user: User = Depends(get_current_user)):
    """Any authenticated user can fetch their own profile."""
    return current_user


@router.get("/admin-only", response_model=UserOut)
def admin_only_example(current_user: User = Depends(require_role("admin"))):
    """Example of role-gating: only users with role='admin' can reach this."""
    return current_user
