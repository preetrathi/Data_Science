"""
Data access layer for User.

SECURITY NOTE: every query here goes through the SQLAlchemy ORM query
builder (`select(...).where(...)`). This means user input is ALWAYS bound
as a parameter, never concatenated into a SQL string. This is what
actually prevents SQL injection — not a WAF, not "sanitizing" input by
hand. If you ever find yourself writing `text(f"... {user_input} ...")`
anywhere in this codebase, stop — that's the pattern that causes breaches.
"""
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.security import hash_password
from app.models.user import User
from app.schemas.user import UserCreate


def get_user_by_email(db: Session, email: str) -> User | None:
    stmt = select(User).where(User.email == email)  # parameterized automatically
    return db.execute(stmt).scalar_one_or_none()


def get_user_by_id(db: Session, user_id: str) -> User | None:
    stmt = select(User).where(User.id == user_id)
    return db.execute(stmt).scalar_one_or_none()


def create_user(db: Session, user_in: UserCreate) -> User:
    db_user = User(
        email=user_in.email,
        hashed_password=hash_password(user_in.password),
        full_name=user_in.full_name,
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user


def register_failed_login(db: Session, user: User, max_attempts: int = 5, lock_minutes: int = 15) -> None:
    """Account-level brute-force lockout — a second layer of defense in
    addition to the IP-based rate limiter on the login endpoint."""
    from datetime import datetime, timedelta, timezone

    user.failed_login_attempts += 1
    if user.failed_login_attempts >= max_attempts:
        user.locked_until = datetime.now(timezone.utc) + timedelta(minutes=lock_minutes)
    db.commit()


def reset_failed_logins(db: Session, user: User) -> None:
    user.failed_login_attempts = 0
    user.locked_until = None
    db.commit()
