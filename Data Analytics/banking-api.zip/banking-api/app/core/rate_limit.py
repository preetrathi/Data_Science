from slowapi import Limiter
from slowapi.util import get_remote_address

# In production behind a load balancer, make sure X-Forwarded-For is
# trusted correctly (configure your proxy) or get_remote_address will
# rate-limit the load balancer's IP instead of the real client.
limiter = Limiter(key_func=get_remote_address)
