"""
Structured (JSON) logging setup.

Rules baked in on purpose:
  1. Logs are JSON, so they're machine-parseable by any log aggregator
     (ELK, Splunk, Azure Monitor, whatever your ops team standardizes on).
  2. Every request gets a correlation/request ID that flows through all
     log lines for that request — essential for tracing an issue in
     production without grepping blind.
  3. A dedicated AUDIT logger is separate from the general app logger,
     for security-relevant events (login success/failure, permission
     denials, token refresh). Route this to a separate, append-only,
     longer-retention destination in production.
  4. NEVER log: passwords, full tokens, card/account numbers, national
     ID numbers. Mask or omit them. See `mask_sensitive` helper.
"""
import logging
import logging.config
import os
from pythonjsonlogger import jsonlogger

from app.core.config import get_settings

settings = get_settings()

SENSITIVE_KEYS = {"password", "token", "authorization", "card_number", "cvv", "ssn", "ntn", "cnic"}


def mask_sensitive(data: dict) -> dict:
    """Recursively mask sensitive fields before they ever reach a log line."""
    masked = {}
    for k, v in data.items():
        if k.lower() in SENSITIVE_KEYS:
            masked[k] = "***REDACTED***"
        elif isinstance(v, dict):
            masked[k] = mask_sensitive(v)
        else:
            masked[k] = v
    return masked


def setup_logging() -> None:
    os.makedirs(settings.LOG_DIR, exist_ok=True)

    formatter = "%(asctime)s %(levelname)s %(name)s %(request_id)s %(message)s"

    logging_config = {
        "version": 1,
        "disable_existing_loggers": False,
        "formatters": {
            "json": {
                "()": jsonlogger.JsonFormatter,
                "format": formatter,
            },
        },
        "handlers": {
            "console": {
                "class": "logging.StreamHandler",
                "formatter": "json",
            },
            "app_file": {
                "class": "logging.handlers.TimedRotatingFileHandler",
                "filename": f"{settings.LOG_DIR}/app.log",
                "when": "midnight",
                "backupCount": 30,
                "formatter": "json",
            },
            "audit_file": {
                "class": "logging.handlers.TimedRotatingFileHandler",
                "filename": f"{settings.LOG_DIR}/audit.log",
                "when": "midnight",
                "backupCount": 365,  # audit logs kept much longer — check your regulator's requirement
                "formatter": "json",
            },
        },
        "loggers": {
            "app": {
                "handlers": ["console", "app_file"],
                "level": settings.LOG_LEVEL,
                "propagate": False,
            },
            "audit": {
                "handlers": ["console", "audit_file"],
                "level": "INFO",
                "propagate": False,
            },
            "uvicorn": {"handlers": ["console", "app_file"], "level": "INFO"},
        },
    }
    logging.config.dictConfig(logging_config)


class RequestIdFilter(logging.Filter):
    """Injects request_id into every log record so it appears even when
    handlers/formatters don't explicitly pass it."""
    def filter(self, record):
        if not hasattr(record, "request_id"):
            record.request_id = "-"
        return True


app_logger = logging.getLogger("app")
audit_logger = logging.getLogger("audit")
app_logger.addFilter(RequestIdFilter())
audit_logger.addFilter(RequestIdFilter())
