"""
Global exception handlers.

Security principle: a caller (potentially an attacker probing your API)
should NEVER see a raw stack trace, SQL error message, or internal file
path in a response. Those details are logged internally (with the
request_id for correlation) and the client gets a generic, safe message.
"""
from fastapi import FastAPI, Request, status
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from sqlalchemy.exc import SQLAlchemyError

from app.core.logging_config import app_logger


def register_exception_handlers(app: FastAPI) -> None:

    @app.exception_handler(RequestValidationError)
    async def validation_exception_handler(request: Request, exc: RequestValidationError):
        # Pydantic validation errors ARE safe to return — they just say
        # "field X must be an integer", which helps legitimate API consumers.
        return JSONResponse(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            content={"detail": exc.errors()},
        )

    @app.exception_handler(SQLAlchemyError)
    async def db_exception_handler(request: Request, exc: SQLAlchemyError):
        request_id = getattr(request.state, "request_id", "-")
        app_logger.error(
            "database_error",
            extra={"request_id": request_id, "error": str(exc)},
        )
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"detail": "An internal error occurred. Please contact support.", "request_id": request_id},
        )

    @app.exception_handler(Exception)
    async def unhandled_exception_handler(request: Request, exc: Exception):
        request_id = getattr(request.state, "request_id", "-")
        app_logger.error(
            "unhandled_exception",
            extra={"request_id": request_id, "error": str(exc), "type": type(exc).__name__},
        )
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"detail": "An internal error occurred. Please contact support.", "request_id": request_id},
        )
