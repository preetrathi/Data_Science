import time
import uuid

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request

from app.core.logging_config import app_logger


class RequestContextMiddleware(BaseHTTPMiddleware):
    """
    - Generates a unique request/correlation ID for every incoming request
      (or reuses an inbound X-Request-ID if your gateway/load-balancer sets one).
    - Logs method, path, status, and duration for every request — this is
      your baseline access log, separate from business/audit logs.
    - Attaches the ID to the response so client-side support tickets can
      reference the exact request.
    """

    async def dispatch(self, request: Request, call_next):
        request_id = request.headers.get("X-Request-ID", str(uuid.uuid4()))
        request.state.request_id = request_id
        start = time.perf_counter()

        response = await call_next(request)

        duration_ms = round((time.perf_counter() - start) * 1000, 2)
        response.headers["X-Request-ID"] = request_id

        app_logger.info(
            "request_handled",
            extra={
                "request_id": request_id,
                "method": request.method,
                "path": request.url.path,
                "status_code": response.status_code,
                "duration_ms": duration_ms,
                "client_ip": request.client.host if request.client else None,
            },
        )
        return response


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    """
    Adds standard hardening headers to every response. These are cheap,
    high-value defenses against a whole class of browser-based attacks
    (clickjacking, MIME sniffing, protocol downgrade).
    """

    async def dispatch(self, request: Request, call_next):
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Strict-Transport-Security"] = "max-age=63072000; includeSubDomains"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Content-Security-Policy"] = "default-src 'none'"
        response.headers.pop("Server", None)  # don't advertise server/framework details
        return response
