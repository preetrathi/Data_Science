"""
Central application settings.

RULE: Nothing sensitive is ever hardcoded here. Every secret (DB password,
JWT signing key, etc.) is read from environment variables / a secrets
manager. This file only defines *what* settings exist and their types —
Pydantic will validate them and the app will refuse to start if a required
one is missing or malformed. That's a deliberate security feature: a
misconfigured banking API should fail loudly at startup, not silently run
insecurely.
"""
from functools import lru_cache
from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # --- App ---
    APP_NAME: str = "banking-api"
    ENVIRONMENT: str = Field(default="development")  # development | uat | production
    DEBUG: bool = False
    API_V1_PREFIX: str = "/api/v1"

    # --- Security ---
    SECRET_KEY: str  # required, no default — must come from env/secrets manager
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 15      # short-lived on purpose
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7
    ALLOWED_ORIGINS: list[str] = []            # explicit CORS allow-list, never "*"

    # --- Database (SQL Server) ---
    DB_SERVER: str
    DB_NAME: str
    DB_USER: str
    DB_PASSWORD: str
    DB_DRIVER: str = "ODBC Driver 18 for SQL Server"
    DB_ENCRYPT: bool = True                    # enforce encrypted connection to SQL Server

    # --- Rate limiting ---
    RATE_LIMIT_LOGIN: str = "5/minute"
    RATE_LIMIT_DEFAULT: str = "100/minute"

    # --- Logging ---
    LOG_LEVEL: str = "INFO"
    LOG_DIR: str = "logs"

    @field_validator("ENVIRONMENT")
    @classmethod
    def validate_environment(cls, v: str) -> str:
        allowed = {"development", "uat", "production"}
        if v not in allowed:
            raise ValueError(f"ENVIRONMENT must be one of {allowed}")
        return v

    @property
    def SQLALCHEMY_DATABASE_URI(self) -> str:
        # Parameterized connection string via SQLAlchemy's odbc_connect —
        # credentials are never interpolated into raw SQL anywhere in the app.
        odbc = (
            f"DRIVER={{{self.DB_DRIVER}}};"
            f"SERVER={self.DB_SERVER};"
            f"DATABASE={self.DB_NAME};"
            f"UID={self.DB_USER};"
            f"PWD={self.DB_PASSWORD};"
            f"Encrypt={'yes' if self.DB_ENCRYPT else 'no'};"
            f"TrustServerCertificate=no;"
        )
        from urllib.parse import quote_plus
        return f"mssql+pyodbc:///?odbc_connect={quote_plus(odbc)}"


@lru_cache
def get_settings() -> Settings:
    """Cached settings instance — read env once, reuse everywhere."""
    return Settings()
