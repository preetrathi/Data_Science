from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session

from app.core.config import get_settings

settings = get_settings()

# pool_pre_ping avoids "stale connection" errors after SQL Server idle-kills a session.
# fast_executemany speeds up pyodbc bulk inserts significantly.
engine = create_engine(
    settings.SQLALCHEMY_DATABASE_URI,
    pool_pre_ping=True,
    pool_size=10,
    max_overflow=20,
    fast_executemany=True,
    echo=settings.DEBUG,  # only ever True in local dev — logs SQL statements
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def get_db() -> Session:
    """FastAPI dependency — one DB session per request, always closed."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
