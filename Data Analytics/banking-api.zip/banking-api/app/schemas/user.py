import re
from pydantic import BaseModel, EmailStr, Field, field_validator


class UserCreate(BaseModel):
    # EmailStr validates format; extra="forbid" on the model config below
    # rejects any field the client sends that we didn't ask for (a cheap
    # but effective defense against mass-assignment style attacks, e.g.
    # someone slipping `"role": "admin"` into a registration payload).
    model_config = {"extra": "forbid"}

    email: EmailStr
    password: str = Field(..., min_length=12, max_length=128)
    full_name: str = Field(..., min_length=1, max_length=255)

    @field_validator("password")
    @classmethod
    def password_strength(cls, v: str) -> str:
        if not re.search(r"[A-Z]", v):
            raise ValueError("Password must contain an uppercase letter")
        if not re.search(r"[a-z]", v):
            raise ValueError("Password must contain a lowercase letter")
        if not re.search(r"\d", v):
            raise ValueError("Password must contain a digit")
        if not re.search(r"[^\w\s]", v):
            raise ValueError("Password must contain a special character")
        return v


class UserOut(BaseModel):
    model_config = {"from_attributes": True}

    id: str
    email: EmailStr
    full_name: str | None
    role: str
    is_active: bool


class LoginRequest(BaseModel):
    model_config = {"extra": "forbid"}
    email: EmailStr
    password: str = Field(..., max_length=128)


class Token(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"


class RefreshRequest(BaseModel):
    model_config = {"extra": "forbid"}
    refresh_token: str
