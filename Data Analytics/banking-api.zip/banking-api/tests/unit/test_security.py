from app.core.security import (
    create_access_token,
    create_refresh_token,
    decode_token,
    hash_password,
    verify_password,
)


def test_password_hash_and_verify():
    plain = "SuperSecret123!"
    hashed = hash_password(plain)
    assert hashed != plain
    assert verify_password(plain, hashed) is True
    assert verify_password("wrong-password", hashed) is False


def test_access_token_roundtrip():
    token = create_access_token(subject="user-123")
    payload = decode_token(token)
    assert payload is not None
    assert payload["sub"] == "user-123"
    assert payload["type"] == "access"


def test_invalid_token_returns_none():
    assert decode_token("not-a-real-token") is None


def test_refresh_token_type_differs_from_access():
    refresh = create_refresh_token(subject="user-123")
    payload = decode_token(refresh)
    assert payload["type"] == "refresh"
