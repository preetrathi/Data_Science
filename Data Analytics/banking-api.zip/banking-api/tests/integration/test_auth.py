def test_register_success(client):
    resp = client.post(
        "/api/v1/auth/register",
        json={"email": "alice@example.com", "password": "StrongPass123!", "full_name": "Alice"},
    )
    assert resp.status_code == 201
    body = resp.json()
    assert body["email"] == "alice@example.com"
    assert "password" not in body  # never leak the password/hash back


def test_register_weak_password_rejected(client):
    resp = client.post(
        "/api/v1/auth/register",
        json={"email": "bob@example.com", "password": "weak", "full_name": "Bob"},
    )
    assert resp.status_code == 422


def test_register_rejects_unexpected_fields(client):
    """Mass-assignment defense: client shouldn't be able to set role=admin at signup."""
    resp = client.post(
        "/api/v1/auth/register",
        json={
            "email": "eve@example.com",
            "password": "StrongPass123!",
            "full_name": "Eve",
            "role": "admin",
        },
    )
    assert resp.status_code == 422


def test_login_success_and_protected_route(client):
    client.post(
        "/api/v1/auth/register",
        json={"email": "carol@example.com", "password": "StrongPass123!", "full_name": "Carol"},
    )
    login_resp = client.post(
        "/api/v1/auth/login", json={"email": "carol@example.com", "password": "StrongPass123!"}
    )
    assert login_resp.status_code == 200
    token = login_resp.json()["access_token"]

    me_resp = client.get("/api/v1/users/me", headers={"Authorization": f"Bearer {token}"})
    assert me_resp.status_code == 200
    assert me_resp.json()["email"] == "carol@example.com"


def test_login_wrong_password_generic_error(client):
    client.post(
        "/api/v1/auth/register",
        json={"email": "dave@example.com", "password": "StrongPass123!", "full_name": "Dave"},
    )
    resp = client.post("/api/v1/auth/login", json={"email": "dave@example.com", "password": "WrongPassword1!"})
    assert resp.status_code == 401
    assert resp.json()["detail"] == "Incorrect email or password"


def test_login_unknown_email_same_generic_error(client):
    """Prevents account enumeration: unknown email gives the identical
    error as a wrong password for a real account."""
    resp = client.post("/api/v1/auth/login", json={"email": "nobody@example.com", "password": "whatever123!"})
    assert resp.status_code == 401
    assert resp.json()["detail"] == "Incorrect email or password"


def test_protected_route_without_token_rejected(client):
    resp = client.get("/api/v1/users/me")
    assert resp.status_code == 401


def test_sql_injection_style_input_is_harmless(client):
    """Not a real injection test (that requires a live SQL Server), but
    confirms malicious-looking input is treated as ordinary string data,
    not executed — it just fails validation or lookup normally."""
    resp = client.post(
        "/api/v1/auth/login",
        json={"email": "attacker@example.com' OR '1'='1", "password": "irrelevant"},
    )
    assert resp.status_code == 422  # fails EmailStr validation, never reaches the DB
