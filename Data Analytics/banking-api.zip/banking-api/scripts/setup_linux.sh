#!/usr/bin/env bash
# Run on the Linux server (as a user with sudo). Sets up the app under
# a dedicated service account, installs deps, and registers the systemd unit.
set -euo pipefail

APP_DIR="/opt/banking-api"
SERVICE_USER="bankingapp"

echo "Creating dedicated service user (no login shell)..."
sudo useradd --system --no-create-home --shell /usr/sbin/nologin "$SERVICE_USER" || true

echo "Setting up virtual environment..."
sudo mkdir -p "$APP_DIR"
sudo cp -r ./* "$APP_DIR"/
cd "$APP_DIR"
sudo python3 -m venv .venv
sudo ./.venv/bin/pip install -r requirements/prod.txt

echo "Setting ownership and permissions..."
sudo mkdir -p "$APP_DIR/logs"
sudo chown -R "$SERVICE_USER:$SERVICE_USER" "$APP_DIR"
sudo chmod 750 "$APP_DIR"
sudo chmod 640 "$APP_DIR/.env" 2>/dev/null || echo "NOTE: place your real .env at $APP_DIR/.env with chmod 640"

echo "Installing systemd service..."
sudo cp "$APP_DIR/scripts/banking-api.service" /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable banking-api
sudo systemctl start banking-api

echo "Done. Check status with: sudo systemctl status banking-api"
echo "Check logs with: sudo journalctl -u banking-api -f"
