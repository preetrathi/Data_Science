# Run as Administrator on the Windows UAT/production server.
# Sets up a Python virtual env and prepares the app for NSSM to run as a Windows Service.
#
# Prerequisites: Python 3.12 installed and on PATH, ODBC Driver 18 for SQL Server
# installed (download from Microsoft), NSSM (https://nssm.cc/) downloaded and on PATH.

$AppDir = "C:\apps\banking-api"

Write-Host "Creating virtual environment..."
python -m venv "$AppDir\.venv"

Write-Host "Installing dependencies..."
& "$AppDir\.venv\Scripts\pip.exe" install -r "$AppDir\requirements\prod.txt"

Write-Host "Creating logs directory..."
New-Item -ItemType Directory -Force -Path "$AppDir\logs" | Out-Null

Write-Host ""
Write-Host "Next steps:"
Write-Host "1. Place your real .env file at $AppDir\.env (NEVER commit it)."
Write-Host "2. Register the Windows Service:"
Write-Host "   nssm install BankingAPI `"$AppDir\.venv\Scripts\python.exe`" `"-m uvicorn app.main:app --host 127.0.0.1 --port 8000 --workers 4`""
Write-Host "   nssm set BankingAPI AppDirectory `"$AppDir`""
Write-Host "   nssm set BankingAPI AppStdout `"$AppDir\logs\service-stdout.log`""
Write-Host "   nssm set BankingAPI AppStderr `"$AppDir\logs\service-stderr.log`""
Write-Host "   nssm set BankingAPI Start SERVICE_AUTO_START"
Write-Host "   nssm start BankingAPI"
Write-Host "3. Configure IIS (or another reverse proxy) with URL Rewrite + Application"
Write-Host "   Request Routing to forward https://your-domain -> http://127.0.0.1:8000,"
Write-Host "   and bind your TLS certificate at the IIS site level."
